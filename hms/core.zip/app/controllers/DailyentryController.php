<?php

require_once '../app/helpers/Auth.php';
class DailyentryController extends Controller
{
    public function index(){
        Auth::check();
        $dailyEntryModel = $this->model('DailyEntry');
        $dailyEntries = $dailyEntryModel->getAll();
      
        
        $this->view('dailyentry/index', ['dailyEntries' => $dailyEntries] );
        
    }

      public function store()
    {
        $dailyentryModel = $this->model('DailyEntry');
        $dailyentryModel->insert($_POST);
        header("Location: /milk_dairy_app/public/dailyentry/index");
    }
  public function delete($id)
    {
        $dailyentryModel = $this->model('DailyEntry');
        $dailyentryModel->delete($id);
        header("Location: /milk_dairy_app/public/dailyentry/index");
    }


}