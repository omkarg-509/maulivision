<?php
// ini_set('display_errors', 1);
// error_reporting(E_ALL);

require_once '../config/config.php';
require_once '../core/App.php';
require_once '../core/Controller.php';


$app = new App(); 



?>

