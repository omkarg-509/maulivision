<?php
define('BASE_URL', '/milk_dairy_app/public/');
