
</body>
    <script src="<?= BASE_URL ?>js/script.js"></script>

   <!-- General JS Scripts -->
  <script src="<?=BASE_URL?>assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <script src="<?=BASE_URL?>assets/bundles/chartjs/chart.min.js"></script>
  <script src="<?=BASE_URL?>assets/bundles/apexcharts/apexcharts.min.js"></script>
  <!-- Page Specific JS File -->
  <script src="<?=BASE_URL?>assets/js/page/index.js"></script>
  <!-- Template JS File -->
  <script src="<?=BASE_URL?>assets/js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="<?=BASE_URL?>assets/js/custom.js"></script>
</body>
</html>
