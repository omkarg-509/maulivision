<?php require_once '../app/views/layouts/sidebar.php';?>


<div class="main-content">
  <div class="loader"></div>
  <div id="app">

        <section class="section">
          <div class="section-header">
            <h1>Dashboard</h1>
          </div>
          <div class="row">

        
            <div class="col-lg-3 col-md-6 col-sm-6 col-6">
              <div class="card card-statistic-1"><a href="../loan/loan.php">
                <i class="fas fa-book-open card-icon col-green"></i>
                <div class="card-wrap">
                  <div class="padding-20">
                    <div class="text-end">
                      <h5 class="font-light mb-0 text-dark">
                        <i class="ti-arrow-up text-success"></i><?= $data['customerCount'] ?>
                    </div>
                  </div>
                </div> </a>
              </div>
            </div>
               <div class="col-lg-3 col-md-6 col-sm-6 col-6">
              <div class="card card-statistic-1"><a href="../loan/loan.php">
                <i class="fas fa-rupee-sign card-icon col-green"></i>
                <div class="card-wrap">
                  <div class="padding-20">
                    <div class="text-end">
                      <h5 class="font-light mb-0 text-dark">
                        <i class="ti-arrow-up text-success"></i><?= $data['dailyentry'] ?>
                    </div>
                  </div>
                </div> </a>
              </div>
            </div>
        

        
            
          </div>
          




 
        </div>

         <div class="row mt-5">
                    <div class="col-6 col-md-3 col-lg-3">
                        <div class="card  btn btn-default">
                            <a class="card-body  text-center mt-4 mb-2 " href="dailyentry/index"><i class="fas fa-edit " style="font-size:30px ;"></i> </a><a>Daily Entry</a>
                        </div>
                    </div>
                     <div class="col-6 col-md-3 col-lg-3">
                        <div class="card  btn btn-default">
                            <a class="card-body  text-center mt-4 mb-2 " href="customer/index"><i class="fas fa-users " style="font-size:30px ;"></i> </a><a>Customers</a>
                        </div>
                    </div>
                </div>
      </section>
    
  </div>
 </div>
  </div>