<?php

class Database
{
    protected $db;

    public function __construct()
    {
        $this->db = new mysqli("localhost", "root", "", "milk_dairy");
        if ($this->db->connect_error) {
            die("Database connection failed: " . $this->db->connect_error);
        }
    }

    
}

